import React, { useState } from 'react';
import UserFormPage from './userformpage';
import StatsPage from './statspage'; // You’ll create this next

function App() {
  const [users, setUsers] = useState([]);
  const [showStats, setShowStats] = useState(false);

  return (
    <>
      {!showStats ? (
        <UserFormPage
          users={users}
          setUsers={setUsers}
          goToStats={() => setShowStats(true)}
        />
      ) : (
        <StatsPage
          users={users}
          goBack={() => setShowStats(false)}
        />
      )}
    </>
  );
}

export default App;