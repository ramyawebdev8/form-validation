#  Multi-Step User Form with Stats — React App

This is a simple React app where users can fill their **name, gender, and age** across multiple pages. After submitting, a **statistics page** shows:

- Total number of users
- Number of males and females
- Count of users aged **below 18 (children)** and **18 or above (adults)**

---

# Features

-  Multi-step form (Name ➝ Gender ➝ Age ➝ Stats)
-  Real-time user data summary
-  Uses `useState` and `useNavigate` for state and routing
-  Fully built with React and React Router
-  Clean code with no external CSS or Bootstrap

---

# How to Run

npm create vite@latest form-validation
npm install
npm run dev

## Technologies Used
React

React Router DOM

Vite (for development)

JavaScript ES6

## Author 
Build by RAMYA S
